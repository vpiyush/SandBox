/*************************************************************************
 * parameters_file.c
 *
 * Copyright (c) 2010 NetNumber, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of NetNumber, Inc.
 * Use is subject to license terms.
 *
 *************************************************************************/
#include <stdio.h>
#include <strings.h>
#include <stdlib.h>
#include <ctype.h>

#ifndef __USE_BSD
  #define __USE_BSD
#endif

#include <string.h>

#include "../include/parameters_file.h"

/*
 * is_empty_or_comment
 *   A line is considered a comment when the first
 *   non-space/tab char is a '#'.
 * returns: 1 if the line is a comment or empty.
 */
static unsigned int is_empty_or_comment(const char *line) {
   unsigned int pos = 0;
   while(1) {
      char c = line[pos++];
      if(c == '\0' || c == '#') return 1;
      if(!isspace(c)) return 0;
   }
}

/*
 * trim_cc_check
 *  Trim leading/trailing spaces, as well as trailing continuation char '\'.
 *  The given buffer may be modified.
 *  returns: 2 line updated, continuation char found
 *           1 line updated, no continuation char found
 *           0 if no change
 *           -1 if empty
 */
static signed int trim_cc_check(char *line) {
   size_t len = strlen(line);
   if(len > 0) {
      unsigned int spos = 0;
      signed int epos = len - 1;
      unsigned int cc = 0;
      unsigned int tmp = 0;

      /* Null out trailing whitespace (incl NL/CR) and note continuation char */
      while(epos>=0 && ( (isspace(line[epos])!=0) ||
                         (tmp = (line[epos]=='\\')) )) {
         cc|=tmp;
         line[epos] = '\0'; /* write null */
         if(--epos < 0) return -1; /* empty line */
      }

      /* Skip leading whitespace */
      while(spos<len && isspace(line[spos])) {
         ++spos;
      }

      /* Trim/adjust the line */
      if(spos>0) {
         int i = 0;
         while(i<=epos) {
            line[i] = line[i+spos];
            ++i;
         }
      }
      return (cc ? 2 : 1);
   }
   return 0;
}

/*
 * read_config_file
 *
 * returns: >= 0 for line count
 *           -1 on failure, errno is set
 */
signed int read_config_file(const char *filepath, config_t *config) {
   char buf[LINE_LEN]; /* raw line buffer */
   char line[LINE_LEN]; /* processed line buffer */
   unsigned int offset = 0;

   if(filepath != NULL && config != NULL) {
      FILE *fp = fopen(filepath, "r");
      if(fp != NULL) {
         config->count = 0;
         entry_t *current_entry = NULL;
      
         while(fgets(buf, LINE_LEN, fp) != NULL) {
            if(! is_empty_or_comment(buf)) {
               signed int ret = trim_cc_check(buf);
               if(ret == 2) {
                  /* Found continuation char */
                  int len = strlen(buf);
                  signed int remaining = LINE_LEN-offset;
                  if(remaining > 0) {
                     strncpy(&line[offset], buf, remaining);
                  }
                  offset += len;
               } else {
                  if(ret == -1 && offset == 0) {
                     continue;
                  } else {
                     /* Done with line */
                     if(current_entry == NULL) {
                        current_entry = calloc(1, sizeof(entry_t));
                        config->entries = current_entry;
                     } else {
                        current_entry->next_entry = calloc(1, sizeof(entry_t));
                        current_entry = current_entry->next_entry;
                     }
                     current_entry->next_entry = NULL;

                     if(offset == 0) {
                        if((current_entry->entry = strdup(buf)) == NULL) {
                           free_all_entries(config);
                           return -1;
                        }
                     } else {
                        signed int remaining = LINE_LEN-offset;
                        if(remaining > 0) {
                           strncat(&line[offset], buf, remaining);
                        }
                        if((current_entry->entry = strdup(line)) == NULL) {
                           free_all_entries(config);
                           return -1;
                        }
                     }
                     config->count++;
                     offset = 0;
                  }
               }
            }
         }
         fclose(fp);
         return config->count;
      }
   }
   return -1;
}

/**
 * put_entry
 * 
 * @param config
 * @param entry
 * @return total entry count, -1 if an error occurred
 */
signed int put_entry(config_t *config, const char *entry) {
    if(config && entry) {
        entry_t *new_entry = calloc(1, sizeof(entry_t));
        if(new_entry) {
            if (new_entry->entry = strdup(entry)) {
                if(config->entries) {
                    new_entry->next_entry = config->entries;
                }
                config->entries = new_entry;
                config->count++;
                return config->count;
            } else {
                free(new_entry);
            }
        }
    }
    return -1;
}


/**
 * config_contains
 *   Substring match in given config
 * @param config
 * @param match
 * @return ptr to the entry_t containing the entry with the substring match, NULL if none found
 */
entry_t *config_contains(const config_t *config, const char *match) {
    if(config && match) {
        entry_t *current = config->entries;
        while(current) {
            if(current->entry && strstr(current->entry, match)) {
                return current;
            }
            current = current->next_entry;
        }
    }
    return NULL;
}

/**
 * free_all_entries
 * @param config
 */

void free_all_entries(config_t *config) {
    if(config) {
        entry_t *current = config->entries;
        while(current) {
            if(current->entry) {
                free(current->entry);
            }
            entry_t *tmp = current;
            free(tmp);
            current = current->next_entry;
        }
        config->count = 0;
    }
}

/**
 * dump_config
 * @param config
 * @param descriptor
 */
void dump_config(const config_t *config) {
    fprintf(stderr, "count: %d\n", config->count);
    if(config) {
        entry_t *current = config->entries;
        while(current) {
            if(current->entry) {
                fprintf(stderr, "%s\n", current->entry);
            }
            current = current->next_entry;
        }
    }
}
