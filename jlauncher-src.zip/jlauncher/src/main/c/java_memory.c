/****************************************************************************
 * @(#)memory.c
 *
 *  Copyright (c) 2010 NetNumber, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of NetNumber,Inc.
 * Use is subject to license terms.
 *
 * Created on October 5, 2010 3:00:29 PM
 ****************************************************************************/

#include "../include/java_memory.h"

#include <stdlib.h>
#include <stdio.h>

#ifdef _SOLARIS
 
 #include <kstat.h>
 #include <sys/sysinfo.h>
 #include <sys/swap.h>
 #include <unistd.h>
#else
 #include <string.h> 
#endif

#define MAXSTRSIZE 80

static unsigned long get_mem_info(char* item_to_find)
{
    unsigned long ret = 0;
    char item[1024] = {0};
    char mem_info[64] = {0};
    unsigned int mem=0;
        
    FILE* f = fopen ("/proc/meminfo", "r");
    
    if (f) 
    {
        while (fscanf(f, "%s %d %s", item, &mem, mem_info) != EOF) 
        {
            char* ptr = strstr(item, item_to_find);
            if (ptr) 
            {
                ret = (unsigned long)mem * (unsigned long)1024; // mem is in kB
                break;
            }
        }
        
        fclose(f);
    } else {
        return 0;
    }
    
    return ret;
}

unsigned long mem_get_total_physical_memory()
{
#ifdef _SOLARIS
    
    static long pagesize = 0;
    static kstat_ctl_t *kc;
    static kstat_t *sys_pagesp;
    kstat_named_t *kn;
    long physmem;

    pagesize = sysconf(_SC_PAGESIZE);

    /* Get the constant values (pagesize and lotsfree) once */
    if ((kc = kstat_open()) == 0) {
        return -1;
    }

    if ((sys_pagesp = kstat_lookup(kc, "unix", 0, "system_pages")) == 0) {
        return -1;
    }

    if (kstat_read(kc, sys_pagesp, 0) == -1) {
        return -1;
    }

    if ((kn = kstat_data_lookup(sys_pagesp, "physmem")) == 0) {
        return -1;
    }

    physmem = kn->value.ul;

    kstat_close(kc);

    return physmem*pagesize;

#else
   return get_mem_info("MemTotal:");
#endif
}

unsigned long mem_get_total_swap_memory()
{
#ifdef _SOLARIS

    long pagesize = 0;
    long swap_total = 0;
    swaptbl_t *swap_table;
    char *strtab;
    int device_idx;
    int devices;
    
    pagesize = sysconf (_SC_PAGESIZE);

    if ((devices = swapctl (SC_GETNSWP, 0)) == -1)
    {
        return -1;
    }

    swap_table = (swaptbl_t *) malloc (devices * sizeof (swapent_t) + sizeof (struct swaptable));
    if (!swap_table)
    {
        return -1;
    }
    
     /* allocate num+1 path holders */
    strtab = (char *) malloc((devices + 1) * MAXSTRSIZE);
    if (!strtab)
    {
        free (swap_table);
        return -1;
    }

    /* initialize path pointers */
    for (device_idx = 0; device_idx < devices + 1; device_idx++)
    {
        swap_table->swt_ent[device_idx].ste_path = strtab + (device_idx * MAXSTRSIZE);
    }

    swap_table->swt_n =  devices + 1;
    if (swapctl (SC_LIST, swap_table) < 0)
    {
        free (strtab);
        free (swap_table);
        return -1;
    }

    for (device_idx = 0; device_idx < devices; device_idx++)
    {
        swap_total += swap_table->swt_ent[device_idx].ste_pages * pagesize;
    }

    free (strtab);
    free (swap_table);

    return swap_total;

#else
   return get_mem_info("SwapTotal:");
#endif
}
