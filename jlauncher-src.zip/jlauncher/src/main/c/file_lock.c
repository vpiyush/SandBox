/*************************************************************************
 * file_lock.c
 *
 * Copyright (c) 2013 NetNumber, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of NetNumber, Inc.
 * Use is subject to license terms.
 *
 *************************************************************************/
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include "../include/file_lock.h"

#ifdef _LINUX 
 typedef struct flock flock_t;
 #include <string.h>
#endif

#define BUFSZ 16
static ssize_t write_pid(int fd) {
   char buf[BUFSZ];
   snprintf(buf, BUFSZ, "%d\n", getpid());
   return write(fd, buf, strlen(buf));
}

static pid_t lock_file_pid(int fd) {
    char buf[BUFSZ+1];
    memset(buf, 0, BUFSZ+1);
    ssize_t ret = read(fd, buf, BUFSZ);
    if(ret > 0) {
       return strtoul(buf, NULL, 10);
    }
    return -1;
}

signed int obtain_file_lock(const char *file_path,
                            file_lock_t *file_lock) {
   if(file_path != NULL && file_lock != NULL) {
      int fd = open(file_path, O_RDWR|O_CREAT, S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP);
      if(fd != -1) {
         flock_t flock;
         memset(&flock, 0, sizeof(flock_t));
         flock.l_type = F_WRLCK;
         memset(file_lock, 0, sizeof(file_lock_t));
         if(fcntl(fd, F_SETLK, &flock) == -1) {
            file_lock->current_owner = lock_file_pid(fd);
            close(fd);
            return FILE_LOCK_IS_LOCKED;
         }

         file_lock->_file_path = file_path;
         if(write_pid(fd) != -1) {
            file_lock->_fd = fd;
            return FILE_LOCK_OKAY;          
         }
         close(fd);
      }
   }
   return FILE_LOCK_ERROR;
}

void release_file_lock(file_lock_t *file_lock) {
   if(file_lock != NULL) {
      if(file_lock->_fd >= 0) {
          close(file_lock->_fd);
          file_lock->_fd = -1;
      }
      if(file_lock->_file_path != NULL) {
         unlink(file_lock->_file_path);
      }
   }
}
