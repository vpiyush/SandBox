/************************************************************************
 * java_launcher.c
 *
 * Copyright (c) 2010 NetNumber, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of NetNumber, Inc.
 * Use is subject to license terms.
 *
 *************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifndef __USE_BSD
  #define __USE_BSD
#endif

#include <string.h>

#include "../include/parameters_file.h"
#include "../include/java_launcher.h"

#include <jni.h>

static JavaVM *jvm = NULL;

JNIEnv* get_env()
{
    JNIEnv* env=0;
    if (jvm)
    {
        if ((*jvm)->AttachCurrentThread(jvm, (void**)&env, NULL) < 0)
        {
            return 0;
        }
    }
    
    return env;
}

/*
 * initialize_jvm
 */
int initialize_jvm (const char *root_dir, config_t *vm_cfg)
{
   JavaVMInitArgs vm_args;
   int i = 0;
   int ret = 0;

   if (getenv("DEBUG")) {
       fprintf(stderr,"root directory: %s\n", root_dir ? root_dir : "not set");
       dump_config(vm_cfg);
   }

   vm_args.ignoreUnrecognized = JNI_TRUE;
   vm_args.version = JNI_VERSION_1_6;
   vm_args.nOptions = vm_cfg->count;
   vm_args.options = (JavaVMOption *)malloc(sizeof(JavaVMOption) * vm_args.nOptions);

   entry_t *current = vm_cfg->entries;
   while(current && (i < vm_cfg->count)) {
       vm_args.options[i].optionString = current->entry;
       current = current->next_entry;
       i++;
   }

   JNIEnv* env=0;

   if ((ret = JNI_CreateJavaVM(&jvm, (void**)&env, &vm_args)) != JNI_OK) {
       free (vm_args.options);
       fprintf(stderr, "Failed to create JVM: %d\n", ret);
       return 1;
   }

   free (vm_args.options);
   return 0;
}

/*
 * daemonize
 */
int daemonize()
{
    pid_t pid = fork();
    if (pid < 0) return 1; /* fork error */
    if (pid > 0) exit (0); /* parent exits */
    /* child (daemon) continues */

    /* New process group */
    setsid();

    return 0;
}

/*
 * uninitialize_jvm
 */
int uninitialize_jvm()
{
    if (jvm != NULL && ((*jvm)->DestroyJavaVM(jvm) != JNI_OK))
    {
        return 1;
    }

    jvm = NULL;

    return 0;
}

/*
 * start_server
 */
int start_server(const char *root_dir,
                 const char *effective_user,
                 const char *product_family,
                 const char *main_class,
                 const char *main_method)
{
    
    jclass initClass = NULL;
    jmethodID methodID = NULL;
    jint ret = 0;
    JNIEnv *env = get_env();

    if (jvm == NULL || env == NULL)
    {
        fprintf(stderr, "JVM is not initialized.\n");
        return 1;
    }

    umask(002);

    if ((initClass = (*env)->FindClass(env, main_class)) == NULL)
    {
        fprintf(stderr, "Failed to locate main class '%s'\n", main_class);
        if (((*env)->ExceptionOccurred(env)) != NULL)
        {
            (*env)->ExceptionDescribe(env);
        }
        return 1;
    }

    if ((methodID = (*env)->GetStaticMethodID(env, initClass, main_method, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V")) == NULL)
    {
        fprintf(stderr, "Failed to locate method '%s'\n", main_method);
        if (((*env)->ExceptionOccurred(env)) != NULL)
        {
            (*env)->ExceptionDescribe(env);
        }
        return 1;
    }

    jstring juser = (*env)->NewStringUTF(env, effective_user);
    jstring jrootdir = (*env)->NewStringUTF(env, root_dir);
    jstring jproduct = (*env)->NewStringUTF(env, product_family);
    ret = (*env)->CallStaticIntMethod(env, initClass, methodID, juser, jrootdir, jproduct);

    if (((*env)->ExceptionOccurred(env)) != NULL)
    {
        (*env)->ExceptionDescribe(env);
        return 1;
    }
    return ret;
}


/*
 * start_application
 *   Expected java entry point is:
 *    <Class>.<StaticMethod>(String rootDir, String user, String[] args)
 *
 * TODO: fix the return code here.  if return early with an error how can we
 * tell?  Maybe use an out error buffer?
 */
int start_application(const char *root_dir,
                      const char *user,
                      const char *product_family,
                      const char *main_class,
                      const char *main_method,
                      unsigned int argc,
                      const char *args[])
{
    jclass initClass = NULL;
    jmethodID methodID = NULL;
    jint ret = 0;
    int i = 0;
    JNIEnv *env = get_env();

    if (jvm == NULL || env == NULL)
    {
        fprintf(stderr, "JVM is not initialized.\n");
        return 1;
    }

    umask(002);

    if ((initClass = (*env)->FindClass(env, main_class)) == NULL)
    {
        fprintf(stderr, "Failed to locate main class '%s'\n", main_class);
        if (((*env)->ExceptionOccurred(env)) != NULL)
        {
            (*env)->ExceptionDescribe(env);
        }
        return 1;
    }

    if ((methodID = (*env)->GetStaticMethodID(env, initClass, main_method,
            "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I")) == NULL)
    {
        fprintf(stderr, "Failed to locate method '%s'\n", main_method);
        if (((*env)->ExceptionOccurred(env)) != NULL)
        {
            (*env)->ExceptionDescribe(env);
        }
        return 1;
    }

    jstring juser = (*env)->NewStringUTF(env, user);
    jstring jrootdir = (*env)->NewStringUTF(env, root_dir);
    jstring jproduct_family = (*env)->NewStringUTF(env, product_family);
    jobjectArray jStrArray =
            (*env)->NewObjectArray(env, argc,
            (*env)->FindClass(env, "java/lang/String"),
            (*env)->NewStringUTF(env, ""));
    
    for (i=0; i < argc; i++)
    {
        (*env)->SetObjectArrayElement(env, jStrArray, i,
                (*env)->NewStringUTF(env, args[i]));
    }

    ret = (*env)->CallStaticIntMethod(env, initClass, methodID,
            jrootdir, juser, jproduct_family, jStrArray);
    
    if (((*env)->ExceptionOccurred(env)) != NULL)
    {
        (*env)->ExceptionDescribe(env);
        return 1;
    }
    return ret;
}

/*
 * read_config
 */
int launcher_read_config(const char *root_dir, const char *prog_name, config_t *vm_config)
{
    /*
      For an app named 'foo', look for vmargs files in the following order:
          foo ==> app specific defaults supplied by user, not installed/updated by packaging.
          foo.default ==> app specific defaults, installed/updated by packaging
          default ==> global defaults, installed/updated by packaging
    */
    char vmoptions_override_file[FILENAME_MAX];
    char vmoptions_file[FILENAME_MAX];
    char def_vmoptions_file[FILENAME_MAX];

    int resultCode;
    if (
      (resultCode = snprintf(vmoptions_override_file, FILENAME_MAX, "%s/sys/bin/.vmargs/%s", root_dir, prog_name) > FILENAME_MAX || resultCode < 0) ||
      (resultCode = snprintf(vmoptions_file, FILENAME_MAX, "%s/sys/bin/.vmargs/%s.default", root_dir, prog_name) > FILENAME_MAX || resultCode < 0) ||
      (resultCode = snprintf(def_vmoptions_file, FILENAME_MAX, "%s/sys/bin/.vmargs/default", root_dir) > FILENAME_MAX || resultCode < 0)
      )
    {
      fprintf(stderr, "Failed to read default vm options file, problem building filenames.\n");
      return 1;
    }

    if (read_config_file(vmoptions_override_file, vm_config) < 0)
    {
        if (read_config_file(vmoptions_file, vm_config) < 0)
        {
            if (read_config_file(def_vmoptions_file, vm_config) < 0)
            {
                fprintf(stderr, "Failed to read default vm options file [%s]: %s\n",
                    def_vmoptions_file, strerror(errno));
                return 1;
            }
        }
    }
    
    return 0;
}
