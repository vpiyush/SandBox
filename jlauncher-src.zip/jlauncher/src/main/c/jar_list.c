/*************************************************************************
 * file_list.c
 *
 * Copyright (c) 2011 NetNumber, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of NetNumber, Inc.
 * Use is subject to license terms.
 *
 *************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

#ifdef _LINUX 
 #include <string.h>
#endif

#include <dirent.h>
#include <errno.h>
#include <strings.h>

#include <fcntl.h>
#include <sys/stat.h>
#include <sys/param.h>

static char *ext_list[] = {".jar", ".zip", NULL};

/**
 * has_extension
 * @param name
 * @param extensions
 * @return 1 if name has one of the extensions, otherwise 0
 */
static unsigned int has_extension(const char *name, char *extensions[]) {
    if (name && extensions) {
        int name_len = strlen(name);
        int i = 0;
        while(extensions[i] != NULL) {
            int ext_len = strlen(extensions[i]);
            int name_pos = name_len - ext_len;
            if(name_pos>0 && strcasecmp(extensions[i], name+name_pos) == 0) {
                return 1;
            }
            i++;
        }
    }
    return 0;
}

/**
 * jar_list
 *   Given a directory, build a list of JAR & ZIP files.
 * @param base_dir
 * @param output_buf
 * @param buf_len
 * @param offset
 * @param entry_separator
 * @return >=0 the length in the output buffer,
 *         -1 if an error occurred
 */
signed int jar_list(const char *base_dir,
                    char *output_buf,
                    unsigned int buf_len,
                    unsigned int offset,
                    const char *entry_separator) {
    struct dirent **namelist;
    char path[MAXPATHLEN];
    int ret = 1;
    int i = 0;
    int c = scandir(base_dir, &namelist, NULL, &alphasort);
    while(i<c) {
        if (ret == 1) {
            struct stat stat_buf;
            char *current = namelist[i]->d_name;
            /* Exclude hidden files, "." and ".." dirs */
            if(current[0] != '.') {
                snprintf(path, MAXPATHLEN, "%s/%s", base_dir, current);
                if(stat(path, &stat_buf)==0) {
                    if(S_ISDIR(stat_buf.st_mode)) {
                        /* directory */
                        offset = jar_list(path, output_buf, buf_len, offset, entry_separator);
                        if (offset == -1) {
                            ret = -1;
                        }
                    } else if(S_ISREG(stat_buf.st_mode)) {
                        /* file */
                        if(has_extension(current, ext_list)) {
                            offset += snprintf(output_buf+offset, buf_len-offset,
                                               "%s%s", path, entry_separator);
                            if(offset >= buf_len) {
                                ret = -1;
                            }
                        }
                    }
                }
            }
        }
        free(namelist[i]);
        i++;
    }
    free(namelist);
    return ret != -1 ? offset : ret;
}
