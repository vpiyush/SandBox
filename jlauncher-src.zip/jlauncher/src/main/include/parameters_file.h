/*************************************************************************
 * parameters_file.h
 *
 * Copyright (c) 2010 NetNumber, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of NetNumber, Inc.
 * Use is subject to license terms.
 *
 *************************************************************************/
#ifndef _PARAMS_FILE_H
#define _PARAMS_FILE_H

#ifdef  __cplusplus
extern "C" {
#endif

#define LINE_LEN 16384

typedef struct {
    char *entry;
    void *next_entry;
} entry_t;

typedef struct {
    int count;
    entry_t *entries;
} config_t;

signed int read_config_file(const char *, config_t *);
signed int put_entry(config_t *, const char *);
entry_t *config_contains(const config_t *, const char *);
void free_all_entries(config_t *);
void dump_config(const config_t *);

#ifdef	__cplusplus
}
#endif

#endif /* _PARAMS_FILE_H */
