/*************************************************************************
 * file_list.h
 *
 * Copyright (c) 2011 NetNumber, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of NetNumber, Inc.
 * Use is subject to license terms.
 *
 *************************************************************************/
#ifndef _FILE_LIST_H
#define _FILE_LIST_H

#ifdef  __cplusplus
extern "C" {
#endif

signed int jar_list(const char *base_dir,
                    char *output_buf,
                    unsigned int buf_len,
                    unsigned int offset,
                    const char *entry_separator);


#ifdef	__cplusplus
}
#endif

#endif /* _FILE_LIST_H */
