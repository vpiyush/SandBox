/* 
 * File:   java_util.h
 * Author: root
 *
 * Created on November 1, 2010, 4:20 PM
 */

#ifndef JAVA_UTIL_H
#define	JAVA_UTIL_H

#ifdef	__cplusplus
extern "C" {
#endif

/**
 * Raises a JNI Exception. If env is null an attempt will be made to
 * attache the calling thread to the env. The constructor for the exception must
 * take a string only.
 *
 * @param env       the JNIEnv pointer for the current thread. If env
 *                  is null an attempt will be made to attache the
 *                  calling thread to the env.
 * @param classPath The classpath of the exception to raise
 * @param msg       The message to set in the exception
 */
inline void throwException(JNIEnv* env, const char* classPath, const char* msg)
{
    if ((*env)==0) {
        return; // We tried to attach but couldn't, so we can't do anything
    }

    jclass except = (*env)->FindClass(env, classPath);

    if (except==0)
        return; // Can't do anything

    (*env)->ThrowNew(env, except, msg);
}

#ifdef	__cplusplus
}
#endif

#endif	/* JAVA_UTIL_H */

