/*************************************************************************
 * java_launcher.h
 *
 * Copyright (c) 2010 NetNumber, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of NetNumber, Inc.
 * Use is subject to license terms.
 *
 *************************************************************************/

#ifndef _LAUNCHER_H
#define _LAUNCHER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <jni.h>
#include "parameters_file.h"

int daemonize();

JNIEnv* get_env();

int initialize_jvm(const char *root_dir, config_t *vm_cfg);

int launcher_read_config(const char *root_dir,
                const char *prog_name,
                config_t *vm_config);

int start_application(const char *root_dir,
                      const char *user,
                      const char *product_family,
                      const char *main_class,
                      const char *main_method,
                      unsigned int argc,
                      const char *args[]);

int start_server(const char *root_dir,
                 const char *effective_user,
                 const char *product_family,
                 const char *main_class,
                 const char *main_method);

int uninitialize_jvm();

#ifdef __cplusplus
}
#endif

#endif /* _LAUNCHER_H */
