/****************************************************************************
 *  @(#)JavaMethod.h
 *
 * Copyright (c) 2002 NetNumber, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of NetNumber,Inc.
 * Use is subject to license terms.
 * Created: 1/30/2003
 *****************************************************************************/

#ifndef JAVAMETHOD_H
#define JAVAMETHOD_H

namespace nn
{
namespace java
{
    /**
     * A <code>JavaMethod</code> is simply a container class for JNI
     * methods. It does not free memory associated with the character
     * pointers. It is designed to be used to point to some static
     * constant string.
     *
     * @author David A Jackson
     * @version 1.00, 1/30/2003
     */
    struct JavaMethod
    {
        const char* method;
        const char* sig;
    };

} //END util namespace
} //END nn namespace

#endif 
