/* 
 * File:   java_util.h
 * Author: root
 *
 * Created on November 1, 2010, 4:20 PM
 */

#ifndef MEMORY_H
#define	MEMORY_H

#ifdef	__cplusplus
extern "C" {
#endif


unsigned long mem_get_total_physical_memory();

unsigned long mem_get_total_swap_memory();


#ifdef	__cplusplus
}
#endif

#endif	/* JAVA_UTIL_H */