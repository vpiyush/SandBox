/*************************************************************************
 * file_lock.h
 *
 * Copyright (c) 2013 NetNumber, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of NetNumber, Inc.
 * Use is subject to license terms.
 *
 *************************************************************************/
#include <sys/types.h>

#ifndef _FILE_LOCK_H
#define _FILE_LOCK_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
   pid_t current_owner;
   const char * _file_path;
   int _fd;
} file_lock_t;

#define FILE_LOCK_OKAY       0
#define FILE_LOCK_IS_LOCKED -1
#define FILE_LOCK_ERROR     -2

/**
 * obtain_file_lock
 * @param filepath - file path name for lock file, can not be null.
 * @param file_lock - file_lock_t structure to be updated upon obtaining lock,
 *                    can not be null.
 * @return FILE_LOCK_OKAY if file lock is obtained, file_lock
 *         FILE_LOCK_IS_LOCKED if file lock can not be obtained because it is
 *                   already locked.  file_lock.other_locked contains info
 *                   regarding the process currently holding the lock
 *         FILE_LOCK_ERROR other failure
 */
signed int obtain_file_lock(const char *file_path,
                            file_lock_t *file_lock);

/**
 * release file_lock
 * @param file_lock - file_lock_t structure of existing file lock
 */
void release_file_lock(file_lock_t *file_lock);

#ifdef __cplusplus
}
#endif

#endif /* _FILE_LOCK_H */
